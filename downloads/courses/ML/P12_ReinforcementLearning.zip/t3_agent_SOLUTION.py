# -*- coding: utf-8 -*-
"""
Reinforcement learning agent for Tic-Tac-Toe

Autor: stdm
Creation: Feb 14, 2018


Description of a model:
-----------------------

The model (=(going to be) trained RL agent) consists of a dictionary V that 
maps states (=board configurations see description in t3_engine.py) to values 
(estimated probability to win from this state for the first player, X).

The model here is trained as sketched in the introductory section of [Sutton & 
Barto, 1998; sec. 1.4]
"""

import pickle
import random
import numpy as np
import matplotlib.pyplot as plt
import math
import t3_engine as engine


def load_model(file_name):
    """
    Loads a trained MODEL from disk specified by FILE_NAME.
    Returns None on failure, the MODEL otherwise.
    """
    with open(file_name, 'rb') as f:
        model = pickle.load(f)
    return model #no error handling yet
    

def save_model(model, file_name):
    """
    Saves the learned MODEL to the a file specified by FILE_NAME.
    Returns True on success.
    """
    with open(file_name, 'wb') as f:
        pickle.dump(model, f)
    return True #no error handling yet


def get_best_action(board, model, symbol = ' ', get_worst = False):
    """
    Once the agent has a trained MODEL, this function applies it to the current 
    BOARD (see description at the top of t3_engine.py) and returns its best 
    move (FIELD where to set it's SYMBOL). If GET_WORST is True, actually the 
    best move for the opponent is returned (needed for self-play).
    Returns the FIELD number of the best move (1-9).
    """
    if symbol==' ':
        symbol = engine.whos_turn(board)
    field = 0
    best_value = (-999999 if get_worst==False else 999999)

    for i in range(9): #evaluate the model for each free field, greedily take best move
        if board[i]==' ':
            new_board = engine.insert_symbol(board, symbol, i+1)
            new_value = model[new_board]
            if (new_value>best_value and get_worst==False) or (new_value<best_value and get_worst==True):
                best_value = new_value
                field = i+1
    assert(field>0 and field<10)
               
    return field


def get_worst_action(board, model, symbol = ' '):
    """
    To be called for the second player, O, who actually wants to minimize the 
    value of moves (as we save the prob. of winning in the value function only
    from the first player's, X's, perspective).
    """
    return get_best_action(board, model, symbol, True)

          
def get_random_action(board):
    """
    Before the agent has a trained MODEL, this function can be used to get a 
    truely random action (i.e., a move on a rondom empty field from the BOARD).
    Returns the FIELD number of a random possible move (1-9).
    """
    
    options = []
    for i in range(9):
        if board[i]==' ':
            options.append(i)
    assert(len(options)>0)
    
    field = random.choice(options) + 1
    assert(field>0 and field<10)
    
    return field


def make_training_move(board, model, previous_state, symbol, exploration_rate=0.1, step_size=0.01):
    """
    Perform a move during training, thereby
        (a) choosing greedily the best move according to the current model
            with probability (1-exploration_rate)
        (b) chosing a random move with probability exploration_rate
        (c) updating the board (from current state to new state s') with the 
            chosen move
        (d) updating the model with the temporal difference learning updating
            rule: V[s] <- V[s] + step_size * (V[s']-V[s])
            where V is the value_function from get_initial_model()
    Returns the new BOARD (and updates the MODEL directly by modifying the 
    probability to win of state PREVIOUS_STATE)
    """
    field = 0
    
    #choose as action, explore with prob. exploration_rate
    do_greedy = np.random.choice([True, False], p=[1-exploration_rate, exploration_rate])
    if do_greedy:
        if symbol=='X':
            field = get_best_action(board, model, symbol)
        else: #O has to minimize, not maximize
            assert(symbol=='O')
            field = get_worst_action(board, model, symbol)
        
        
        #this is actually important, and I first misunderstood it from the 
        #presentation in Sutton&Barto'schapter 1: s is NOT the current state,
        #but the last state where it was the same player's turn. the current 
        #state is a state that this player will never encounter, so it 
        #doesn't help updating it with this player's probability to win.
        s = previous_state 
        s_prime = engine.make_move(board, field, symbol) #update board
        assert(s_prime!='')
        model[s] = model[s] + step_size*( model[s_prime] - model[s] ) #update model according to TD learning update rule, thereby perform the move
        return s_prime
       
    else:
        field = get_random_action(board) #no learning takes place with exploratory moves
        return engine.make_move(board, field, symbol) #update board


def learn_from_final_move(model, who_won, last_board_X, last_board_O):
    """
    make_training_move() lets the current player learn from his current move;
    to profit from the final state of the game (possibly reached by a winning
    move of the opponent), this function updates the last state of the losing
    player with the information that he is going to lose.
    Returns nothing, but updates the MODEL (preciselye, the winning 
    probability of the last state LAST_BOARD_* of the not winning player 
    i.e, the opposite of WHO_WON). WHO_WON is either 'X' or 'O', and 
    LAST_BOARD_* is a board state.
    """
    if who_won=='X': #hack to acouint for learning from a move that leads to losing in the next move of the opponent (who would otherwise only be gut updated himself, without feedback on us)
        model[last_board_O] = 1
    else:
        model[last_board_X] = 0
    return


def enumerate_states():
    """
    Returns a list of all possible states, encoded as strings
    """
    states = []
    symbols = [' ', 'X', 'O']
    for a in range(3):
        for b in range(3):
            for c in range(3):
                for d in range(3):
                    for e in range(3):
                        for f in range(3):
                            for g in range(3):
                                for h in range(3):
                                    for i in range(3):
                                        state = symbols[a] + symbols[b] + symbols[c] + symbols[d] + symbols[e] + symbols[f] + symbols[g] + symbols[h] + symbols[i]
                                        x_o_diff = engine.count_symbol(state, 'X') - engine.count_symbol(state, 'O')
                                        if x_o_diff>=0 and x_o_diff<2: #only those states can occure in practice (turn-based game) that have max. one X more than O
                                            states.append(state)
    return states


def get_initial_model():
    """
    Returns an initial (=untrained) model as described above (Description of a 
    model)
    """
    value_function = {} # an empty dict
    for state in enumerate_states():
        game_over, who_won, reward = engine.evaluate(state)
        #according to [Sutton & Barto, 1998; p. 11]:
        if game_over:
            value_function[state] = (1 if who_won=='X' else 0) #this way, 'O' optimizes not to loose (instead of to win), because winning and draw is equaly incentivized
        else:
            value_function[state] = 0.5 
        
    return value_function


def plot_values(model):
    """
    Creates a plot of the values, organized in a 2d grid
    """
    values = np.array(list(model.values()))
    side_length = math.ceil(math.sqrt(values.size))
    values = np.append(values, np.zeros(side_length**2 - values.size))
    grid = values.reshape((side_length, side_length))
    
    #this grid gives the probs for the 9 starter moves
    grid_starter = [[model['X        '], model[' X       '], model['  X      ']], 
                    [model['   X     '], model['    X    '], model['     X   ']], 
                    [model['      X  '], model['       X '], model['        X']]]
    
    plt.ion()
    plt.subplot(211)
    plt.hist(values, bins=20)
    plt.yscale('log', nonposy='clip')
    plt.subplot(223)
    plt.imshow(grid, cmap='gray')
    plt.colorbar()
    plt.subplot(224)
    plt.imshow(grid_starter, cmap='gray')
    plt.colorbar()
    plt.show()
