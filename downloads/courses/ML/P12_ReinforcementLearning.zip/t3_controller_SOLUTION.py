# -*- coding: utf-8 -*-
"""
Tic-Tac-Toe controller

Autor: stdm
Creation: Feb 14, 2018

"""

import random
import t3_agent_SOLUTION as agent
import t3_engine as engine


#Some definitions to configure the behaviour of this controller
training_mode = True
nr_training_games = 1000000
train_by_self_play = True
epsilon = 0.2 #exploration rate
alpha = 0.001 #learning rate
model_file_name = 't3-rl-agent.pickle'


#control both training and playing
def main():
    random.seed()
    
    print('Welcome to the Tic-Tac-Toe self-play RL agent environment.')
    engine.print_help()

    #train a RL agent by self-play
    if training_mode:
        print('Starting training for ' + str(nr_training_games) + ' rounds: ')
        model = agent.get_initial_model()
        turns = ['X', 'O']
        eps = epsilon
        a = alpha
        wins = {'X':0, 'O':0, 'Nobody':0}
                
        #outer loop over N games
        for i in range(nr_training_games):
            board = engine.get_initial_board()
            last_board_X = board[:]
            last_board_O = board[:]
            iteration = 0
                    
            #inner loop: a single training game
            while True:
                turn = turns[iteration%2] #2-play game -> turns always flip
                if turn=='X': 
                    board = agent.make_training_move(board, model, last_board_X, turn, eps, a)
                    last_board_X = board[:]
                    assert(board!='')
                else:
                    assert(turn=='O')
                    if train_by_self_play: 
                        board = agent.make_training_move(board, model, last_board_O, turn, eps, a)
                        last_board_O = board[:]
                    else: #in case of no self-play, a random agent plays the part of the human
                        field, symbol = agent.get_random_action(board, turn)
                        board = engine.make_move(board, field, turn)
                        last_board_O = board[:]
                    assert(board!='')
                    
                game_over, who_won, reward = engine.evaluate(board)
                iteration = iteration+1
                if game_over:
                    wins[who_won] = wins[who_won]+1
                    agent.learn_from_final_move(model, who_won, last_board_X, last_board_O)
                    break
            
            if i>0 and i%100==0:
                print('.', end='', flush=True)
            if i>0 and i%10000==0:
                print('\nX won ' + str(wins['X']) + ' of the last batch of games and ' + str(wins['Nobody'])  + ' of these games where draw after ' + str(i) + ' runs.')
                ok = agent.save_model(model, model_file_name)
                assert(ok==True)
                agent.plot_values(model)
                wins = {'X':0, 'O':0, 'Nobody':0}
                
        print('\nTraining finished.')
            
    #apply a trained RL agent in a game aghainst a human
    else: #training_mode==False
        board = engine.get_initial_board()
        model = agent.load_model(model_file_name)
        print('You are player O, the computer starts.')
        
        while True:
            turn = engine.whos_turn(board)
            if turn=='X': #get the agent's input, make the respective move                
                field = agent.get_best_action(board, model, turn)
                board = engine.make_move(board, field, turn)
                assert(board!='')
            else: #get player's input (until valid) and make the respective move
                while True: 
                    field = input("Which field to set? ")
                    board = engine.make_move(board, field, turn)
                    if board!='':
                        break
            
            #print new state, evaluate game
            print('Game after ' + turn + "'s move: ")
            engine.print_board(board, False)
            game_over, who_won, reward = engine.evaluate(board)
            
            if game_over:
                print('The game is over. ' + who_won + ' won.')
                break

    return # end of main()


# start the script if executed directly    
if __name__ == '__main__':
    
    main()
