# -*- coding: utf-8 -*-
"""
Created on Wed May 13 15:43:44 2015

@author: stdm
"""

import matplotlib.pyplot as plt
import pandas as pd

#Load data
data_frame = pd.read_excel("hydrocarbons.xlsx")
print(data_frame)

#Plot X vs. Y
plt.scatter(data_frame['nr_molecules'], data_frame['heat_release'])
plt.title("Scatter Plot X vs. Y")
plt.xlabel(data_frame.columns[1])
plt.ylabel(data_frame.columns[2])
plt.show()


'''
import xlrd

#Load data
wb = xlrd.open_workbook('hydrocarbons.xlsx')
sheet = wb.sheet_by_index(0)
X_train = [] #molecules
Y_train = [] #heat released
print sheet.nrows
for i in range(1, sheet.nrows): #skip header row
    X_train.append(sheet.cell(i, 1).value)
    Y_train.append(sheet.cell(i, 2).value)

#Plot X vs. Y
plt.scatter(X_train, Y_train)
plt.xlabel(sheet.cell(0, 1).value)
plt.ylabel(sheet.cell(0, 2).value)
plt.title("Scatter Plot X vs. Y")
plt.show()
'''