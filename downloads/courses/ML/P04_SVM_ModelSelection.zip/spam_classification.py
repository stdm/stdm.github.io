# -*- coding: utf-8 -*-
"""
Created on Wed July 30 14:35:28 2015

@author: stmf
update: stdm, Feb 23, 2018: migrated to Python 3
"""

import pandas as pd
import numpy as np
import csv

from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import BaggingClassifier

from email_processing import EmailProcessor #for optional task


###############################################################################
###   Hyper-parameters
###############################################################################
params_svm_linear = {'kernel': 'linear', 'C': 1}
params_svm_rbf = {'kernel': 'rbf', 'gamma': 1e-3, 'C': 10}
params_naive_bayes = {'alpha': 1.0}
params_random_forest = {'max_depth': 5, 'n_estimators': 10}
params_ada_boost = {'n_estimators': 50}


###############################################################################
###   M A I N   
###############################################################################
def main():
    # 1. Load train and test data
    X_train = load_data("training_features_spam.csv")
    y_train = load_data("training_labels_spam.csv").ravel()

    X_test = load_data("test_features_spam.csv")
    y_test = load_data("test_labels_spam.csv").ravel()

    # 2. Train different models
    algorithms = [SVC(**params_svm_linear),
                  SVC(**params_svm_rbf),
                  LogisticRegression(),
                  MultinomialNB(**params_naive_bayes),
                  RandomForestClassifier(**params_random_forest),
                  AdaBoostClassifier(**params_ada_boost)]
    classifiers = train_models(algorithms, X_train, y_train)

    # 3. Apply the trained models
    apply_models(classifiers, X_test, y_test)
    
    # 3.1 Apply majority vote ensemble of ensembles    
    predictions = apply_models_majority_vote(classifiers, X_test)
    test_accuracy = calc_accuracy(predictions, y_test)
    print('Testing with majority vote:')
    print('\tAccuracy with %d %ss: %.5f' % (len(classifiers), classifiers[0].__class__.__name__, test_accuracy))

    # 4. Write predictions to submission file
    write_predictions('submission_spam.csv', X_test, predictions)

    # 5.-7. [Optional] Further investigations on own emails in text file format
    apply_to_own_mails(classifiers)


###############################################################################
###   utility function to load data
###############################################################################
def load_data(dataset_name):
    '''
    Loads the pre-processed binary data from a csv file identified by the given
    dataset_name.
    :param dataset_name: defines the csv file to be loaded
    :return: the pre-processed data in binary form
    '''
    df = pd.read_csv(dataset_name, header=None, sep=';')
    return np.array(df)


###############################################################################
###   functions controlling learning & application of the model(s)
###############################################################################
def train_models(algorithms, X, y):
    '''
    Trains different bagging classifiers with the given training data X and y.
    One bagging classifier will be trained for each given algorithm.
    Each bagging classifier contains 5 classifiers (also called estimators)
    again. Per bagging classifier defines one of the given algorithms the type
    of the estimators. The estimators are trained on 5 diffrent samples of
    the given training data X an y.
    :param algorithms:  list containing the algorithms used to train the
                        bagging classifiers
    :param X:           training samples
    :param y:           training labels
    :return:            the trained bagging classifiers
    '''
    classifiers = []
    for algorithm in algorithms:
        #######################################################################
        # Part 3.a: Building independent bootstrap samples
        # TODO: Understand this code, including the bootstrap_samples() function
        X_sample, y_sample = bootstrap_samples(X, y)
        params_bagging = {'base_estimator': algorithm, 'n_estimators': 5}
        clf = BaggingClassifier(**params_bagging)
        classifiers.append(clf.fit(X_sample, y_sample))
        alg_name = get_algorithm_name(algorithm, clf)
        print('Learned %s with %s' % (clf.__class__.__name__, alg_name))
    return classifiers


def bootstrap_samples(X, y):
    '''
    Randomly draws samples from X and the corresponding labels y. The number of
    samples drawn should be the same as the number of samples contained in X.
    Ensure that the sampling is done with replacement.

    Caution: The drawn labels must be at the same index position as the
    corresponding samples drawn from X!
    (Tipp: you can couple X and y with np.column_stack((X, y)) )
    :param X:   training samples
    :param y:   training labels
    :return:    the randomly drawn samples from X and their corresponding labels
    '''
    Xy = np.column_stack((X, y))
    indices = np.random.choice(range(0,len(Xy)), len(Xy))
    Xy_samples = Xy[indices, :]
    X_samples = Xy_samples[:, 0:Xy.shape[1]-1]
    y_samples = Xy_samples[:, Xy.shape[1]-1]
    return X_samples, y_samples


def apply_models(classifiers, X, y):
    '''
    Applies the trained models independently on the test data X and labels y 
    and prints the testing errors for each layer of the classifiers.
    E.g. given a bagging classifier with 5 random forest estimators:
        BaggingClassifier contains 5 RandomForestClassifier estimators
            1. estimator accuracy: 0.50000         <- LAYER 1: RandomForestClassifier
            2. estimator accuracy: 0.50000         <- LAYER 1: RandomForestClassifier
            3. estimator accuracy: 0.50000         <- ...
            4. estimator accuracy: 0.50000         <- ...
            5. estimator accuracy: 0.50000         <- ...
        Overall accuracy of BaggingClassifier: 0.50000  <- layer 2: BaggingClassifier

    :param classifiers: list of classifiers to be applied on the given
                        test data X and y
    :param X:           test samples
    :param y:           test lables
    '''
    print('\n\nTesting with single classifiers:\n')
    for clf in classifiers:
        estms = clf.estimators_
        alg_name = get_algorithm_name(estms[0], clf)
        print('\t%s contains %d %s estimators' % (clf.__class__.__name__, len(estms), alg_name))
        for i, estm in enumerate(estms):
            predictions = estm.predict(X)
            print('\t\t%d. estimator accuracy: %.5f' % (i+1, calc_accuracy(predictions, y)))

        predictions = clf.predict(X); # predicts 0 or 1
        test_accuracy = calc_accuracy(predictions, y)
        print('\tOverall accuracy of %s: %.5f\n' % (clf.__class__.__name__, test_accuracy))


def apply_models_majority_vote(classifiers, X):
    '''
    Applies the trained models by majority vote on the test data X and y and
    returns the predictions as list. The predictions must contain 0 (no spam)
    or 1 (spam)
    E.g.:   predictions = [1, 0, 0, 1, 1, 0, ..., 1]  (with length same as len(X)
    :param classifiers: list of classifiers to be applied on the given
                        test set X
    :param X:           test samples
    :return:            the predictions by majority vote
    '''

    # predictions have to be returned after majority vote of given classifiers
    # on test set X
    predictions = []

    ###########################################################################
    # Part 3.b: Simple (unweighted) majority vote
    # TODO: Insert your code here and remove the following line of dummy code
    predictions = np.round(np.random.random(len(X)))

    return predictions


###############################################################################
###   N O   N E E D   T O   R E A D    C O D E    B E L O W    ! ! !
###
###   utility function to write data in the leader board service format
###############################################################################
def write_predictions(file_name, X, predictions):
    '''
    Writes the given predictions to a file named file_name
    :param file_name:   name of the file to write the predictions to
    :param X:           used to verify the length of the predictions
    :param predictions: predictions to be written to a file
    '''
    predictions_file = open(file_name, 'w', newline='')
    open_file_object = csv.writer(predictions_file, delimiter=';')
    open_file_object.writerow(['key', 'value'])
    open_file_object.writerows(list(zip(list(range(0, len(X))), predictions)))
    predictions_file.close()
    print('\nPredictions written to %s' % file_name)


###############################################################################
###   evaluation functions to score the results of an applied model
###############################################################################
def calc_accuracy(predictions, y):
    '''
    Calculates the accuracy of the given predictions based on the ground truth
    labels y
    :param predictions: predictions made by a classifiers on a test set with
                        corresponding labels y
    :param y:           ground truth labels
    :return:            the accuracy of the given predictions
    '''
    error = calc_error(predictions, y)
    return 1 - error


def calc_error(predictions, y):
    '''
    Calculates the error of the given predictions based on the ground truth
    labels y
    :param predictions: predictions made by a classifiers on a test set with
                        corresponding labels y
    :param y:           ground truth labels
    :return:            the error of the given predictions
    '''
    error_count = sum(1 for i, prediction in enumerate(predictions) if prediction != y[i])
    prediction_count = float(len(predictions))
    return error_count / prediction_count


def get_algorithm_name(algorithm, classifier):
    '''
    Returns the name of the given algorithm and the name of the
    corresponding kernel in case of an SVM classifier
    :param algorithm:   algorithm the return the name for
    :param classifier:  classifier to get the kernel name from in
                        case of a SVM classifier
    :return:            the name of the given algorithm
    '''
    if(algorithm.__class__.__name__ == 'SVC'):
        algoritm_name = algorithm.__class__.__name__ + '-' + classifier.estimators_[0].kernel
    else:
        algoritm_name = algorithm.__class__.__name__
    return algoritm_name


###############################################################################
###   extensions and calling of main()
###############################################################################
def apply_to_own_mails(classifiers):
    '''
    This functions extend the main method by the optional part of classifying
    own mails with the just trained classifyer (for further investigations)
    :param classifiers: the just trained full ensemble
    '''    
    file_name = 'spamSample1.txt'
    input_prompt = 'Enter\n1. Name of text file containing a single own email (full absolute path)\n2. Or 0 (zero) to abort\n-> '
    while True:
        file_name = input(input_prompt)
        if file_name == '0':
            break
        else:
            #try :
            # 5. Load vocabulary and email to classify
            vocab_file = open('vocab_list.txt', 'r')
            vocab_list = vocab_file.read().split(chr(10))
            email_file = open(file_name, 'r')
            email = email_file.read()

            # 6. Pre-process email
            ep =  EmailProcessor(vocab_list=vocab_list)
            # word_indices = ep.process_email(email)
            word_indices = ep.process_email(email)
            email_features = ep.extract_features(word_indices, len(vocab_list));

            # 7. Classify email
            email_classification = ep.classify(classifiers, [email_features])
            print('\n\tEmail classified as: %s\n' % email_classification)
            #except :
            #    print('\nERROR! COULD NOT LOAD FILE: %s\n' % file_name)


# start the script if executed directly
if __name__ == '__main__':
    main()
