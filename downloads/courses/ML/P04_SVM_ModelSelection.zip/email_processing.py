import numpy as np
import re
from nltk.stem import PorterStemmer
from nltk.tokenize import RegexpTokenizer

class EmailProcessor():

    def __init__(self, vocab_list):
        self.vocab_list = vocab_list

    def process_email(self, email_content):
        '''
        Preprocesses a the body of an email and returns a list of word_indices
        word_indices of the words contained in the email.

        Steps done:
        Lower-casing / Stripping HTML / Normalizing URLs /
        Normalizing Email Addresses / Normalizing Numbers /
        Normalizing Dollars / Word Stemming / Removal of non-words

        :param email_content:   textual representation of an email
        :return:                a list of word_indices word_indices of the words
                                contained in the email_content
        '''

        # Lower case
        email_content = email_content.lower()

        # Strip all HTML
        # Looks for any expression that starts with < and ends with > and does not have any < or > in the tag
        # and replace it with a space
        tag_pattern = re.compile('<[^<>]+>')
        email_content = tag_pattern.sub(' ', email_content)

        # Handle Numbers
        # Look for one or more characters between 0-9
        number_pattern = re.compile('[0-9]+')
        email_content = number_pattern.sub('number', email_content)

        # Handle URLS
        # Look for strings starting with http:// or https://
        url_pattern = re.compile('(http|https)://[^\s]*')
        email_content = url_pattern.sub('httpaddr', email_content)

        # Handle Email Addresses
        # Look for strings with @ in the middle
        email_pattern = re.compile('[^\s]+@[^\s]+')
        email_content = email_pattern.sub('emailaddr', email_content)

        # Handle $ sign
        dollar_pattern = re.compile('[$]+')
        email_content = dollar_pattern.sub('dollar', email_content)

        return self.tokenize_email(email_content)


    def tokenize_email(self, email_content):
        '''
        Splits the given email_content in separate tokens. The delimiters are
        defined as any punctuations and empty spaces between words

        :param email_content:   textual representation of an email
        :return:                the tokens (words) speparated from each other
        '''
        word_indices = []

        # Tokenize and also get rid of any punctuation
        tokenizer = RegexpTokenizer('[a-zA-Z0-9]+[\']{0,1}[a-zA-Z0-9]+')
        tokens = tokenizer.tokenize(email_content)

        for token in tokens:

            # Remove any non alphanumeric characters
            non_alphanumeric_pattern = re.compile('[^a-zA-Z0-9]')
            token = non_alphanumeric_pattern.sub('', token)

            # Stem the word
            stemmer = PorterStemmer()
            token = stemmer.stem(token.strip())

            # Skip the word if it is too short
            if len(token) < 1:
                continue

            # Look up the word in the dictionary and add to word_indices if founds
            if token in self.vocab_list:
                word_index = self.vocab_list.index(token)
                word_indices.append(word_index)

        return word_indices


    def extract_features(self, word_indices, feature_count):
        '''
        Takes in a word_indices vector and produces a feature vector from the
        word indices.
        :param word_indices:    indices of words defined in a word vector
        :param feature_count:   number of possible features of an email
        :return:                the binary representation of an email
        '''
        email_features = np.zeros(feature_count)
        email_features[word_indices] = email_features[word_indices] + 1
        return np.array(email_features).transpose()


    def classify(self, classifiers, X):
        '''
        Classifies the given data by majority vote of the given classifiers
        :param classifiers:
        :param X:
        :return:
        '''

        votes = 0
        for clf in classifiers:
            votes += clf.predict(X); # predicts 0 or 1
        clf_count = float(len(classifiers))
        for vote in votes:
            if vote <= clf_count/2.0:
                return 'OK'
            else:
                return 'SPAM'